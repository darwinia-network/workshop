# Setup

* Install dependencies and run the app

```
yarn install;
yarn run dev;
```

* Open the app in your browser at http://localhost:8000

```
open -a "Google Chrome" http://localhost:8000
```
